// Beat grid lagu isq - crimes (hasil analisis audio): ~122.2 BPM, 1 beat = 0.491 detik
export const FPS = 30;
export const DURATION = 690; // 23 detik (0:00 - 0:23)
export const WIDTH = 1080;
export const HEIGHT = 1920;

export const BEAT_S = 0.491;
export const OFFSET_S = 0.008;

/** frame tempat beat ke-n jatuh */
export const bf = (n: number) => Math.round((OFFSET_S + n * BEAT_S) * FPS);

/** posisi beat (desimal) pada frame tertentu */
export const beatPos = (frame: number) => (frame / FPS - OFFSET_S) / BEAT_S;

/** 1 tepat di beat, meluruh ke 0 sebelum beat berikutnya */
export const pulse = (frame: number, k = 5) => {
  const p = beatPos(frame);
  return Math.exp(-(p - Math.floor(p)) * k);
};

/** aksen lebih besar tiap 8 beat (batas frasa lagu) */
export const phrase = (frame: number, k = 3) => {
  const q = beatPos(frame) / 8;
  return Math.exp(-(q - Math.floor(q)) * 8 * k * 0.35);
};

// Batas adegan (dalam beat). Semua potongan jatuh tepat di beat.
export const SCENES = {
  hook: 0,
  reveal: 8,
  player: 16,
  burst: 24,
  carousel: 32,
  outro: 40,
} as const;
