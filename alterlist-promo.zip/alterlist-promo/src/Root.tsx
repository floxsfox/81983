import React from "react";
import { Composition } from "remotion";
import { Promo } from "./Promo";
import { DURATION, FPS, HEIGHT, WIDTH } from "./beats";

export const Root: React.FC = () => {
  return (
    <Composition
      id="AlterlistPromo"
      component={Promo}
      durationInFrames={DURATION}
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
    />
  );
};
