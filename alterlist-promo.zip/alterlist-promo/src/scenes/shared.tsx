import React from "react";
import { Img, staticFile } from "remotion";
import { Glass } from "../kit/Glass";
import { BIG, Pop } from "../kit/Pop";
import { C, FONT } from "../theme";

/** satu baris judul besar, rata tengah, muncul tepat di `at` */
export const CapLine: React.FC<{
  at: number;
  out?: number;
  top: number;
  size?: number;
  color?: string;
  children: React.ReactNode;
}> = ({ at, out, top, size = 108, color = "#fff", children }) => (
  <div style={{ position: "absolute", left: 0, right: 0, top, textAlign: "center" }}>
    <Pop at={at} out={out}>
      <span style={{ ...BIG, fontSize: size, color, whiteSpace: "nowrap" }}>{children}</span>
    </Pop>
  </div>
);

/** pil merek kecil di atas layar */
export const BrandPill: React.FC<{ at: number; top?: number }> = ({ at, top = 54 }) => (
  <div style={{ position: "absolute", left: 0, right: 0, top, display: "flex", justifyContent: "center" }}>
    <Pop at={at} dist={30}>
      <Glass radius={48} blur={20} tint="rgba(250,1,7,0.12)" style={{ height: 72 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "0 30px 0 20px", height: 72, fontFamily: FONT, fontWeight: 700, fontSize: 36, letterSpacing: "-0.02em", color: "#fff" }}>
          <Img src={staticFile("logo.png")} style={{ width: 44, height: 44 }} />
          Alterlist
        </div>
      </Glass>
    </Pop>
  </div>
);

export { C };
