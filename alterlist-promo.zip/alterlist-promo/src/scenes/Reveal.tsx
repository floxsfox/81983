import React from "react";
import { useCurrentFrame } from "remotion";
import { COPY } from "../copy";
import { bf } from "../beats";
import { Backdrop } from "../kit/Backdrop";
import { Logo3D } from "../kit/Logo3D";
import { Pop, BIG } from "../kit/Pop";
import { useBeatFx } from "../kit/fx";
import { FONT } from "../theme";
import { clamp, eOutBack, eOutExpo, lerp, prog, rng } from "../util";

const T = (b: number) => bf(b) - bf(8);
const EMBERS = (() => {
  const r = rng(21);
  return Array.from({ length: 34 }, () => ({ a: r() * Math.PI * 2, v: 14 + r() * 36, s: 4 + r() * 9, l: 0.5 + r() * 0.5 }));
})();

export const Reveal: React.FC = () => {
  const f = useCurrentFrame();
  const { g, p } = useBeatFx();
  const k = prog(f, 0, 30);
  const scale = lerp(0.25, 1, eOutBack(k, 1.5));
  const spin = lerp(300, 0, eOutExpo(k));
  const ring = prog(f, 0, 26);
  const word = COPY.brand.split("");
  return (
    <div style={{ position: "absolute", inset: 0 }}>
      <Backdrop colors={["#FA0107", "#7a0a14", "#1c2a52"]} />

      {/* gelombang kejut */}
      {[0, 6].map((d) => {
        const rr = prog(f, d, 28);
        return (
          <div
            key={d}
            style={{
              position: "absolute",
              left: 540 - 400,
              top: 900 - 400,
              width: 800,
              height: 800,
              borderRadius: "50%",
              border: `${8 - rr * 6}px solid rgba(255,90,95,${0.8 * (1 - rr)})`,
              boxShadow: `0 0 80px rgba(250,1,7,${0.6 * (1 - rr)})`,
              transform: `scale(${0.2 + rr * 2.4})`,
            }}
          />
        );
      })}
      {/* percikan */}
      {EMBERS.map((e, i) => {
        const tt = f * 1.0;
        const d = e.v * Math.pow(prog(f, 0, 40), 0.5) * 22;
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: 540 + Math.cos(e.a) * d - e.s / 2,
              top: 900 + Math.sin(e.a) * d - e.s / 2 + tt * 0.6,
              width: e.s,
              height: e.s,
              borderRadius: "50%",
              background: i % 3 ? "#ff3b3f" : "#fff",
              opacity: clamp(1 - prog(f, 0, 44) / e.l),
              boxShadow: "0 0 14px 3px rgba(250,1,7,0.7)",
            }}
          />
        );
      })}

      {/* logo 3D */}
      <div style={{ position: "absolute", left: 540 - 260, top: 900 - 260, transform: `scale(${scale})`, opacity: clamp(k * 5) }}>
        <Logo3D size={520} rotY={spin + Math.sin(g / 26) * 9} rotX={-8 + Math.cos(g / 31) * 4} depth={44} shine={prog(f, 8, 30)} glow={0.7 + 0.3 * p} />
      </div>

      {/* wordmark per huruf */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 1200, textAlign: "center", display: "flex", justifyContent: "center" }}>
        {word.map((ch, i) => (
          <Pop key={i} at={T(9) + i * 2} dist={60} dur={14}>
            <span style={{ ...BIG, fontFamily: FONT, fontSize: 190, letterSpacing: "-0.04em" }}>{ch}</span>
          </Pop>
        ))}
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 1430, textAlign: "center" }}>
        <Pop at={T(10)} dist={40}>
          <span style={{ ...BIG, fontSize: 58, fontWeight: 500, color: "#d4d4d6", letterSpacing: "-0.01em" }}>{COPY.tagline}</span>
        </Pop>
      </div>
    </div>
  );
};
