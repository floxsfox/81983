import React from "react";
import { useCurrentFrame } from "remotion";
import { COPY } from "../copy";
import { bf } from "../beats";
import { Backdrop } from "../kit/Backdrop";
import { Glass } from "../kit/Glass";
import { Icon } from "../kit/Icon";
import { Logo3D } from "../kit/Logo3D";
import { BIG, Pop } from "../kit/Pop";
import { useBeatFx } from "../kit/fx";
import { FONT } from "../theme";
import { clamp, eOutBack, eOutExpo, lerp, prog } from "../util";

const T = (b: number) => bf(b) - bf(40);

export const Outro: React.FC = () => {
  const f = useCurrentFrame();
  const { g, p } = useBeatFx();
  const k = prog(f, 0, 30);
  const word = COPY.brand.split("");
  return (
    <div style={{ position: "absolute", inset: 0 }}>
      <Backdrop colors={["#FA0107", "#8a0a18", "#1c2a52"]} />
      <div style={{ position: "absolute", left: 540 - 270, top: 760 - 270, transform: `scale(${lerp(0.4, 1, eOutBack(k, 1.4))})`, opacity: clamp(k * 5) }}>
        <Logo3D size={540} rotY={lerp(200, 0, eOutExpo(k)) + Math.sin(g / 24) * 14} rotX={-6 + Math.cos(g / 30) * 5} depth={48} shine={prog(f, 10, 34)} glow={0.7 + 0.3 * p} />
      </div>

      <div style={{ position: "absolute", left: 0, right: 0, top: 1090, display: "flex", justifyContent: "center" }}>
        {word.map((ch, i) => (
          <Pop key={i} at={T(40.7) + i * 2} dist={60} dur={14}>
            <span style={{ ...BIG, fontSize: 200, letterSpacing: "-0.04em" }}>{ch}</span>
          </Pop>
        ))}
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 1335, textAlign: "center" }}>
        <Pop at={T(41.6)} dist={40}>
          <span style={{ ...BIG, fontSize: 62, fontWeight: 500, color: "#d4d4d6", letterSpacing: "-0.01em" }}>{COPY.tagline}</span>
        </Pop>
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 1480, display: "flex", justifyContent: "center" }}>
        <Pop at={T(42.3)} dist={40}>
          <Glass radius={60} blur={22} tint="rgba(250,1,7,0.2)" sheen={((f * 0.018) % 1.5) - 0.2}>
            <div style={{ display: "flex", alignItems: "center", gap: 20, padding: "22px 50px 22px 36px", fontFamily: FONT, fontWeight: 700, fontSize: 52, color: "#fff", letterSpacing: "-0.01em" }}>
              <Icon name="phone" size={54} />
              {COPY.outro.sub}
            </div>
          </Glass>
        </Pop>
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 1700, display: "flex", justifyContent: "center" }}>
        <Pop at={T(43)} dist={30}>
          <Glass radius={44} blur={18} strength={0.8} shadow={false}>
            <div style={{ padding: "18px 44px", fontFamily: FONT, fontWeight: 600, fontSize: 40, color: "#e8e8ea", letterSpacing: "0.01em" }}>{COPY.outro.credit}</div>
          </Glass>
        </Pop>
      </div>
    </div>
  );
};
