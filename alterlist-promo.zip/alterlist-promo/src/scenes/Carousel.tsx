import React from "react";
import { useCurrentFrame } from "remotion";
import { COPY } from "../copy";
import { BEAT_S, FPS, bf } from "../beats";
import { Backdrop } from "../kit/Backdrop";
import { Glass } from "../kit/Glass";
import { Icon } from "../kit/Icon";
import { useBeatFx } from "../kit/fx";
import { Effects } from "../screens/Effects";
import { Home } from "../screens/Home";
import { Library } from "../screens/Library";
import { NowPlaying } from "../screens/NowPlaying";
import { Search } from "../screens/Search";
import { C, FONT } from "../theme";
import { clamp, eOutExpo, lerp, prog } from "../util";
import { BrandPill, CapLine } from "./shared";
import { Pop } from "../kit/Pop";

const T = (b: number) => bf(b) - bf(32);
const BEAT_F = BEAT_S * FPS;
const N = 5;
const CARD_SCALE = 1.38;
const CW = 390 * CARD_SCALE;
const CH = 844 * CARD_SCALE;
const RADIUS = 640;

export const Carousel: React.FC = () => {
  const f = useCurrentFrame();
  const { p } = useBeatFx();
  // satu beat = satu putaran 72 derajat, snap dengan easing
  const x = Math.max(0, f / BEAT_F);
  const step = Math.floor(x);
  const angle = (step + eOutExpo(clamp((x - step) / 0.6))) * (360 / N);
  const enter = eOutExpo(prog(f, 0, 24));
  const screens = [
    <Home key="h" f={f} />,
    <Search key="s" f={f} />,
    <Library key="l" f={f} />,
    <NowPlaying key="n" lyr={0.0} active={1} />,
    <Effects key="e" sel={3} k={1} />,
  ];
  const streakIn = prog(f, T(36), 18);
  return (
    <div style={{ position: "absolute", inset: 0 }}>
      <Backdrop colors={["#FA0107", "#5a0a12", "#241048"]} />
      <BrandPill at={4} />

      <CapLine at={T(32.2)} out={T(36) - 2} top={206}>
        {COPY.carousel.l1}
      </CapLine>
      <CapLine at={T(34)} out={T(36) - 2} top={330} color="#FA0107">
        {COPY.carousel.l2}
      </CapLine>
      <CapLine at={T(36)} top={206}>
        {COPY.carousel.l3}
      </CapLine>
      <CapLine at={T(38)} top={330} color="#FA0107">
        {COPY.carousel.l4}
      </CapLine>

      {/* cincin 3D layar aplikasi */}
      <div style={{ position: "absolute", left: 540 - CW / 2, top: 1050 - CH / 2, width: CW, height: CH, perspective: 2000, perspectiveOrigin: "50% 40%", opacity: enter }}>
        <div
          style={{
            position: "absolute",
            inset: 0,
            transformStyle: "preserve-3d",
            transform: `translateZ(${-RADIUS + lerp(-700, 0, enter)}px) rotateX(${-7 + Math.sin(f / 40) * 2}deg) rotateY(${-angle}deg)`,
          }}
        >
          {screens.map((sc, i) => (
            <div
              key={i}
              style={{
                position: "absolute",
                inset: 0,
                transform: `rotateY(${i * (360 / N)}deg) translateZ(${RADIUS}px)`,
                backfaceVisibility: "hidden",
              }}
            >
              <div style={{ width: CW, height: CH, borderRadius: 74, overflow: "hidden", boxShadow: "0 0 0 4px #0a0a0b, 0 0 0 6px rgba(255,255,255,0.22), 0 40px 90px rgba(0,0,0,0.6)", position: "relative" }}>
                <div style={{ width: 390, height: 844, transform: `scale(${CARD_SCALE})`, transformOrigin: "0 0" }}>{sc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* kartu streak */}
      {streakIn > 0 && (
        <div style={{ position: "absolute", left: 0, right: 0, top: 1668, display: "flex", justifyContent: "center" }}>
          <Pop at={T(36)} dist={90}>
            <Glass radius={72} blur={26} tint="rgba(250,1,7,0.22)" sheen={((f * 0.02) % 1.5) - 0.2}>
              <div style={{ display: "flex", alignItems: "center", gap: 30, padding: "30px 56px 30px 40px", fontFamily: FONT, color: "#fff" }}>
                <div style={{ width: 112, height: 112, borderRadius: "50%", background: "linear-gradient(145deg,#ff8a45,#FA0107)", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 0 50px rgba(250,1,7,0.7)", transform: `scale(${1 + 0.08 * p})` }}>
                  <Icon name="flame" size={68} />
                </div>
                <div style={{ lineHeight: 1.1 }}>
                  <div style={{ fontSize: 60, fontWeight: 700, letterSpacing: "-0.02em" }}>Streak 14 hari</div>
                  <div style={{ display: "flex", gap: 12, marginTop: 14 }}>
                    {Array.from({ length: 7 }, (_, i) => (
                      <i key={i} style={{ width: 26, height: 26, borderRadius: "50%", background: i < Math.min(7, Math.floor(prog(f, T(36) + 6, 24) * 8)) ? "#FA0107" : "rgba(255,255,255,0.22)", boxShadow: i < 6 ? "0 0 14px rgba(250,1,7,0.8)" : "none" }} />
                    ))}
                  </div>
                </div>
              </div>
            </Glass>
          </Pop>
        </div>
      )}
    </div>
  );
};
