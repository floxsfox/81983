import React from "react";
import { useCurrentFrame } from "remotion";
import { COPY } from "../copy";
import { bf } from "../beats";
import { Backdrop } from "../kit/Backdrop";
import { Glass } from "../kit/Glass";
import { Icon } from "../kit/Icon";
import { useBeatFx } from "../kit/fx";
import { FONT } from "../theme";
import { clamp, eInCubic, eOutBack, lerp, prog } from "../util";
import { ENERGY } from "../envelope";
import { CapLine } from "./shared";

const T = (b: number) => bf(b) - bf(0);
const CHIPS: { x: number; y: number; icon: "play" | "phone" | "download"; delay: number }[] = [
  { x: 300, y: 860, icon: "play", delay: 2 },
  { x: 770, y: 1080, icon: "phone", delay: 3 },
  { x: 380, y: 1310, icon: "download", delay: 4 },
];

/** gelombang suara di bawah: tinggi batang mengikuti energi lagu */
const Wave: React.FC<{ fade: number }> = ({ fade }) => {
  const { g } = useBeatFx();
  const bars = 41;
  return (
    <div style={{ position: "absolute", left: 90, right: 90, top: 1600, height: 220, display: "flex", alignItems: "center", justifyContent: "space-between", opacity: fade }}>
      {Array.from({ length: bars }, (_, i) => {
        const c = Math.abs(i - (bars - 1) / 2) / ((bars - 1) / 2);
        const env = ENERGY[Math.max(0, Math.min(ENERGY.length - 1, g - Math.round(c * 9)))];
        const h = 8 + 200 * env * (1 - c * 0.72) * (0.4 + 0.6 * Math.abs(Math.sin(i * 1.7 + g * 0.33)));
        return <i key={i} style={{ width: 10, height: h, borderRadius: 5, background: "#FA0107", opacity: 0.95 - 0.55 * c, boxShadow: "0 0 18px rgba(250,1,7,0.7)" }} />;
      })}
    </div>
  );
};

export const Hook: React.FC = () => {
  const f = useCurrentFrame();
  const { g, p } = useBeatFx();
  const v = eInCubic(prog(f, T(5.3), T(7.7) - T(5.3)));
  const core = prog(f, T(6.6), T(8) - T(6.6));
  return (
    <div style={{ position: "absolute", inset: 0 }}>
      <Backdrop colors={["#FA0107", "#5a0a12", "#14204a"]} dim={0.25 * (1 - prog(f, 0, 40))} />

      <CapLine at={T(1)} out={T(4.4)} top={300}>
        {COPY.hook.l1}
      </CapLine>
      <CapLine at={T(5)} top={290}>
        {COPY.hook.l2a}
      </CapLine>
      <CapLine at={T(6)} top={410} color="#FA0107">
        {COPY.hook.l2b}
      </CapLine>

      {CHIPS.map((c, i) => {
        const a = T(c.delay);
        const t = prog(f, a, 16);
        const s = eOutBack(t, 1.6);
        const dx = c.x - 540;
        const dy = c.y - 1000;
        const r = Math.hypot(dx, dy) * (1 - v);
        const th = Math.atan2(dy, dx) + v * 2.8 + Math.sin(g / 45 + i) * 0.04;
        const x = 540 + r * Math.cos(th);
        const y = 1000 + r * Math.sin(th) + Math.sin(g / 18 + i * 2) * 14;
        const sc = s * (1 - v * 0.92);
        const op = clamp(t * 4) * (1 - clamp((v - 0.85) * 7));
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: x - 270,
              top: y - 80,
              width: 540,
              opacity: op,
              transform: `perspective(1400px) rotateY(${Math.sin(g / 34 + i) * 16 + (1 - t) * 60}deg) rotateX(${Math.cos(g / 40 + i) * 9}deg) rotateZ(${v * 220}deg) scale(${sc + p * 0.03 * (a <= f ? 1 : 0)})`,
            }}
          >
            <Glass radius={80} blur={24} tint="rgba(250,1,7,0.14)" sheen={((g * 0.011 + i * 0.3) % 1.6) - 0.3} style={{ height: 160 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 26, height: 160, padding: "0 40px 0 26px", fontFamily: FONT, fontWeight: 700, fontSize: 46, color: "#fff", letterSpacing: "-0.02em" }}>
                <div style={{ width: 108, height: 108, borderRadius: "50%", background: "linear-gradient(145deg,#ff4a50,#a0050b)", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 8px 24px rgba(250,1,7,0.5)" }}>
                  <Icon name={c.icon} size={52} />
                </div>
                <span style={{ whiteSpace: "nowrap" }}>{COPY.hook.chips[i]}</span>
              </div>
            </Glass>
          </div>
        );
      })}

      <Wave fade={prog(f, 6, 24) * (1 - v)} />

      {/* inti cahaya sebelum logo muncul */}
      <div
        style={{
          position: "absolute",
          left: 540 - 600,
          top: 1000 - 600,
          width: 1200,
          height: 1200,
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(255,255,255,0.95) 0%, rgba(255,70,74,0.8) 22%, rgba(250,1,7,0.25) 48%, transparent 70%)",
          transform: `scale(${lerp(0.02, 1.15, core * core)})`,
          opacity: core * 0.95,
        }}
      />
    </div>
  );
};
