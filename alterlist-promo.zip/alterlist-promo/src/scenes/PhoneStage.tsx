import React from "react";
import { useCurrentFrame } from "remotion";
import { COPY } from "../copy";
import { BEAT_S, FPS, bf } from "../beats";
import { Backdrop } from "../kit/Backdrop";
import { Phone } from "../kit/Phone";
import { useBeatFx } from "../kit/fx";
import { Effects } from "../screens/Effects";
import { Home } from "../screens/Home";
import { Library } from "../screens/Library";
import { NowPlaying } from "../screens/NowPlaying";
import { Search } from "../screens/Search";
import { clamp, eInOut, eOutExpo, lerp, prog } from "../util";
import { BrandPill, CapLine } from "./shared";

const T = (b: number) => bf(b) - bf(12);
const BEAT_F = BEAT_S * FPS;
const PHONE_SCALE = 1.7;
const PHONE_Y = 456;

/** getaran/ayunan ponsel setiap layar berganti: osilasi teredam */
const kick = (f: number, at: number, amp: number) => {
  const d = f - at;
  return d < 0 ? 0 : amp * Math.exp(-d / 9) * Math.cos(d / 3.1);
};

const Bead: React.FC<{ a: number; front: boolean; fade: number }> = ({ a, front, fade }) => {
  const rx = 520;
  const ry = 150;
  const s = Math.sin(a);
  if ((s >= 0) !== front) return null;
  const size = 64 * (1 + 0.45 * s);
  return (
    <>
      {[0, 1, 2, 3, 4, 5].map((j) => {
        const aj = a - j * 0.09;
        const sj = Math.sin(aj);
        if ((sj >= 0) !== front) return null;
        const sz = size * (1 - j * 0.12);
        return (
          <div
            key={j}
            style={{
              position: "absolute",
              left: 520 + Math.cos(aj) * rx - sz / 2,
              top: 150 + sj * ry - sz / 2,
              width: sz,
              height: sz,
              borderRadius: "50%",
              background: j === 0 ? "radial-gradient(circle at 35% 30%, #fff, #ffb3b5 40%, #FA0107 100%)" : "#ff3b3f",
              opacity: fade * (1 - j * 0.17),
              boxShadow: "0 0 40px 10px rgba(250,1,7,0.65)",
            }}
          />
        );
      })}
    </>
  );
};

export const PhoneStage: React.FC = () => {
  const f = useCurrentFrame();
  const { g, p } = useBeatFx();

  const enter = eOutExpo(prog(f, 0, 30));
  const y = PHONE_Y + lerp(1500, 0, enter);
  const rx = lerp(52, 7, enter) + Math.sin(f / 44) * 2 + p * -0.6;
  const ry = -13 + Math.sin(f / 30) * 7 + kick(f, T(16), 15) + kick(f, T(20), -15) + kick(f, T(14), 6) + kick(f, T(15), -6);
  const rz = Math.sin(f / 52) * 1.4 + lerp(-10, 0, enter);
  const push = lerp(0, 90, prog(f, T(22), T(24) - T(22))) + p * 8;

  // layar
  const swaps = [0, T(14), T(15), T(16), T(20)];
  const idx = swaps.reduce((acc, s, i) => (f >= s ? i : acc), 0);
  const since = f - swaps[idx];
  const tk = idx === 0 ? 1 : eInOut(prog(since, 0, 10));
  const render = (i: number) => {
    if (i === 0) return <Home f={f} />;
    if (i === 1) return <Search f={f} />;
    if (i === 2) return <Library f={f} />;
    if (i === 3) {
      const x = (f - T(17)) / BEAT_F;
      const frac = x - Math.floor(x);
      const active = x < 0 ? 0 : Math.min(4, Math.floor(x) + eInOut(clamp(frac / 0.45)));
      return <NowPlaying lyr={prog(f, T(16) + 5, 26)} active={active} />;
    }
    const selList = [1, 5, 3, 4];
    const si = Math.max(0, Math.min(3, Math.floor((f - T(20)) / BEAT_F)));
    return <Effects sel={selList[si]} k={prog(f, T(20) + 8, 26)} />;
  };
  const screen = (
    <div style={{ position: "absolute", inset: 0, overflow: "hidden" }}>
      {idx > 0 && tk < 1 && (
        <div style={{ position: "absolute", inset: 0, transform: `translateX(${-tk * 110}px)`, opacity: 1 - tk * 0.9 }}>{render(idx - 1)}</div>
      )}
      <div style={{ position: "absolute", inset: 0, transform: `translateX(${(1 - tk) * 390}px)` }}>{render(idx)}</div>
    </div>
  );

  // orbit 8D
  const orbitOn = prog(f, T(22), 10);
  const a = (f - T(22)) * 0.17 + 2;

  return (
    <div style={{ position: "absolute", inset: 0 }}>
      <Backdrop />
      <BrandPill at={T(13)} />

      <CapLine at={T(12.4)} out={T(16) - 2} top={206}>
        {COPY.phone.a1}
      </CapLine>
      <CapLine at={T(13)} out={T(16) - 2} top={330} color="#FA0107">
        {COPY.phone.a2}
      </CapLine>

      <CapLine at={T(16)} out={T(20) - 2} top={206}>
        {COPY.phone.b1}
      </CapLine>
      <CapLine at={T(18)} out={T(20) - 2} top={330} color="#FA0107">
        {COPY.phone.b2}
      </CapLine>

      <CapLine at={T(20)} top={164} size={90}>
        {COPY.phone.fx[0]}
      </CapLine>
      <CapLine at={T(21)} top={252} size={90} color="#FA0107">
        {COPY.phone.fx[1]}
      </CapLine>
      <CapLine at={T(22)} top={340} size={90}>
        {COPY.phone.fx[2]}
      </CapLine>

      {/* cincin orbit (belakang ponsel) */}
      {orbitOn > 0 && (
        <div style={{ position: "absolute", left: 540 - 520, top: 1190 - 150, width: 1040, height: 300, transform: "rotateZ(-12deg)", opacity: orbitOn }}>
          <div style={{ position: "absolute", inset: 0, borderRadius: "50%", border: "3px solid rgba(255,255,255,0.22)", boxShadow: "0 0 40px rgba(250,1,7,0.35)" }} />
          <Bead a={a} front={false} fade={orbitOn} />
        </div>
      )}

      <div style={{ position: "absolute", left: 0, top: 0, width: 1080, height: 1920, transform: `scale(${1 + push / 1500})`, transformOrigin: "540px 1150px" }}>
        <div style={{ position: "absolute", left: 0, top: y, width: 1080, height: 1500 }}>
          <Phone scale={PHONE_SCALE} rx={rx} ry={ry} rz={rz} y={0} glare={0.6 + 0.4 * Math.sin(f / 20)}>
            {screen}
          </Phone>
        </div>
      </div>

      {/* bagian depan orbit */}
      {orbitOn > 0 && (
        <div style={{ position: "absolute", left: 540 - 520, top: 1190 - 150, width: 1040, height: 300, transform: "rotateZ(-12deg)", opacity: orbitOn, pointerEvents: "none" }}>
          <div style={{ position: "absolute", inset: 0, borderRadius: "50%", border: "4px solid rgba(255,255,255,0.55)", clipPath: "inset(50% 0 0 0)", boxShadow: "0 0 30px rgba(250,1,7,0.5)" }} />
          <Bead a={a} front fade={orbitOn} />
        </div>
      )}
    </div>
  );
};
