import React from "react";
import { Img, Sequence, staticFile, useCurrentFrame } from "remotion";
import { COPY } from "../copy";
import { bf } from "../beats";
import { Backdrop } from "../kit/Backdrop";
import { DynamicBar } from "../kit/DynamicBar";
import { Glass } from "../kit/Glass";
import { Icon } from "../kit/Icon";
import { BIG, Pop } from "../kit/Pop";
import { useBeatFx } from "../kit/fx";
import { Art } from "../screens/common";
import { Home } from "../screens/Home";
import { C, FONT } from "../theme";
import { eInOut, eOut, eOutBack, eOutExpo, lerp, prog } from "../util";

type Cols = [string, string, string];
const COLS: Cols[] = [
  ["#FA0107", "#7a0a14", "#1c2a52"],
  ["#ff4a50", "#4a0a40", "#0b1d52"],
  ["#FA0107", "#8a2a10", "#0a3a44"],
  ["#FA0107", "#2a0f5c", "#7a0a14"],
];

/** kotak hero kaca dengan putaran masuk (flip 3D) lalu mengayun */
const Hero: React.FC<{ w?: number; h: number; top: number; children: React.ReactNode }> = ({ w = 860, h, top, children }) => {
  const f = useCurrentFrame();
  const { p } = useBeatFx();
  const k = eOutExpo(prog(f, 2, 24));
  return (
    <div style={{ position: "absolute", left: 540 - w / 2, top, width: w, height: h, opacity: Math.min(1, k * 3) }}>
      <div
        style={{
          width: w,
          height: h,
          transform: `perspective(1800px) rotateY(${lerp(75, 0, k) + Math.sin(f / 26) * 7}deg) rotateX(${lerp(-14, 5, k) + Math.cos(f / 31) * 3}deg) scale(${lerp(0.7, 1, k) + p * 0.012})`,
        }}
      >
        <Glass radius={72} blur={28} tint="rgba(250,1,7,0.1)" sheen={((f * 0.02) % 1.5) - 0.2} style={{ width: w, height: h }}>
          {children}
        </Glass>
      </div>
    </div>
  );
};

const Frame: React.FC<{ i: number; children: React.ReactNode }> = ({ i, children }) => {
  const w = COPY.burst[i].word;
  const size = Math.min(210, 960 / (w.length * 0.5));
  return (
    <div style={{ position: "absolute", inset: 0 }}>
      <Backdrop colors={COLS[i]} />
      <div style={{ position: "absolute", left: 0, right: 0, top: 190, textAlign: "center" }}>
        <Pop at={0} dist={90}>
          <span style={{ ...BIG, fontSize: size, whiteSpace: "nowrap" }}>{w}</span>
        </Pop>
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 190 + size + 18, textAlign: "center" }}>
        <Pop at={4} dist={40}>
          <span style={{ ...BIG, fontSize: 56, fontWeight: 500, color: "#d4d4d6", letterSpacing: "-0.01em" }}>{COPY.burst[i].desc}</span>
        </Pop>
      </div>
      {children}
    </div>
  );
};

const Ring: React.FC<{ v: number; size: number }> = ({ v, size }) => {
  const r = size / 2 - 9;
  const c = 2 * Math.PI * r;
  return (
    <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,0.2)" strokeWidth={10} />
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#FA0107" strokeWidth={10} strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c * (1 - v)} style={{ filter: "drop-shadow(0 0 10px rgba(250,1,7,0.9))" }} />
    </svg>
  );
};

const Unduh: React.FC = () => {
  const f = useCurrentFrame();
  const v = eInOut(prog(f, 12, 32));
  const done = v >= 1;
  return (
    <Frame i={0}>
      <Hero h={800} top={800}>
        <div style={{ padding: "50px 52px", fontFamily: FONT, color: "#fff" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 34, height: 190 }}>
            <Img src={staticFile("cover.jpg")} style={{ width: 160, height: 160, borderRadius: 26, objectFit: "cover" }} />
            <div style={{ flex: 1, lineHeight: 1.15 }}>
              <div style={{ fontSize: 58, fontWeight: 700, letterSpacing: "-0.02em" }}>crimes</div>
              <div style={{ fontSize: 38, color: done ? "#ff6a6e" : C.sub, fontWeight: 500 }}>{done ? "Tersimpan" : "Mengunduh..."}</div>
            </div>
            <div style={{ position: "relative", width: 132, height: 132 }}>
              <Ring v={v} size={132} />
              <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${done ? eOutBack(prog(f, 44, 10), 2.2) : 1})` }}>
                <Icon name={done ? "check" : "download"} size={56} color={done ? "#FA0107" : "#fff"} stroke={3} />
              </div>
            </div>
          </div>
          {[0, 1].map((i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: 34, height: 190, opacity: 0.9 }}>
              <Art i={i === 0 ? 1 : 3} size={160} radius={26} />
              <div style={{ flex: 1, lineHeight: 1.15 }}>
                <div style={{ fontSize: 54, fontWeight: 700, letterSpacing: "-0.02em" }}>{i === 0 ? "Neon Rain" : "Slow Bloom"}</div>
                <div style={{ fontSize: 36, color: C.sub, fontWeight: 500 }}>Bisa diputar offline</div>
              </div>
              <Icon name="check" size={56} color="#FA0107" stroke={3} />
            </div>
          ))}
        </div>
      </Hero>
    </Frame>
  );
};

const Offline: React.FC = () => {
  const f = useCurrentFrame();
  const { p, g } = useBeatFx();
  return (
    <Frame i={1}>
      <div style={{ position: "absolute", left: 540 - 220, top: 800, width: 440, height: 440 }}>
        {[0, 1, 2].map((i) => {
          const q = ((f * 0.022 + i / 3) % 1);
          return <div key={i} style={{ position: "absolute", inset: 0, borderRadius: "50%", border: "3px solid rgba(255,90,95,0.7)", transform: `scale(${1 + q * 1.5})`, opacity: (1 - q) * 0.7 }} />;
        })}
        <div style={{ position: "absolute", inset: 0, transform: `perspective(1400px) rotateY(${Math.sin(f / 22) * 16}deg) rotateX(${Math.cos(f / 26) * 8}deg) scale(${eOutBack(prog(f, 0, 20), 1.6) + p * 0.02})` }}>
          <Glass radius={220} blur={26} tint="rgba(250,1,7,0.18)" sheen={((f * 0.02) % 1.5) - 0.2} style={{ width: 440, height: 440 }}>
            <div style={{ height: 440, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Icon name="wifioff" size={210} stroke={1.8} />
            </div>
          </Glass>
        </div>
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 1320, display: "flex", justifyContent: "center" }}>
        <Pop at={8}>
          <Glass radius={70} blur={22} tint="rgba(250,1,7,0.2)">
            <div style={{ padding: "26px 56px", fontFamily: FONT, fontWeight: 700, fontSize: 56, letterSpacing: "-0.02em" }}>Bisa diputar offline</div>
          </Glass>
        </Pop>
      </div>
      <div style={{ position: "absolute", left: 100, right: 100, top: 1500 }}>
        <Pop at={12}>
          <Glass radius={56} blur={22} style={{ width: 880 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 28, padding: "24px 36px", fontFamily: FONT, color: "#fff" }}>
              <Img src={staticFile("cover.jpg")} style={{ width: 120, height: 120, borderRadius: 24, objectFit: "cover" }} />
              <div style={{ flex: 1, lineHeight: 1.15 }}>
                <div style={{ fontSize: 48, fontWeight: 700 }}>crimes</div>
                <div style={{ height: 8, borderRadius: 4, background: "rgba(255,255,255,0.22)", marginTop: 16 }}>
                  <div style={{ width: `${(0.3 + g / 1600) * 100}%`, height: "100%", borderRadius: 4, background: "#fff" }} />
                </div>
              </div>
              <Icon name="pause" size={68} />
            </div>
          </Glass>
        </Pop>
      </div>
    </Frame>
  );
};

const Lokal: React.FC = () => {
  const f = useCurrentFrame();
  const v = eOut(prog(f, 8, 34));
  const count = Math.floor(311 * v);
  return (
    <Frame i={2}>
      <Hero h={840} top={790}>
        <div style={{ padding: "56px 60px", fontFamily: FONT, color: "#fff" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 26 }}>
            <div style={{ width: 110, height: 110, borderRadius: 30, background: "linear-gradient(145deg,#4d7cff,#0b1d52)", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 10px 30px rgba(0,0,0,0.4)" }}>
              <Icon name="phone" size={60} />
            </div>
            <div style={{ lineHeight: 1.15 }}>
              <div style={{ fontSize: 54, fontWeight: 700, letterSpacing: "-0.02em" }}>Musik di perangkat</div>
              <div style={{ fontSize: 36, color: C.sub, fontWeight: 500 }}>{v < 1 ? "Memindai..." : "Selesai dipindai"}</div>
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "baseline", gap: 22, margin: "44px 0 20px" }}>
            <span style={{ fontSize: 230, fontWeight: 700, letterSpacing: "-0.05em", lineHeight: 1, fontVariantNumeric: "tabular-nums" }}>{count}</span>
            <span style={{ fontSize: 66, fontWeight: 600, color: "#ff6a6e" }}>lagu</span>
          </div>
          <div style={{ height: 14, borderRadius: 7, background: "rgba(255,255,255,0.18)", marginBottom: 40 }}>
            <div style={{ width: `${v * 100}%`, height: "100%", borderRadius: 7, background: "linear-gradient(90deg,#ff4a50,#FA0107)", boxShadow: "0 0 24px rgba(250,1,7,0.8)" }} />
          </div>
          {["Music", "Download", "Favorit"].map((n, i) => (
            <div key={n} style={{ display: "flex", alignItems: "center", gap: 22, height: 74, fontSize: 44, fontWeight: 600, opacity: v > (i + 1) / 4 ? 1 : 0.25 }}>
              <Icon name="folder" size={46} color="#ff6a6e" />
              <span style={{ flex: 1 }}>{n}</span>
              <Icon name="check" size={44} color="#FA0107" stroke={3} />
            </div>
          ))}
        </div>
      </Hero>
    </Frame>
  );
};

const Dynamic: React.FC = () => {
  const f = useCurrentFrame();
  const open = eOutExpo(prog(f, 8, 22));
  return (
    <Frame i={3}>
      <Hero h={980} top={760}>
        <div style={{ position: "absolute", inset: 0, filter: "blur(2px)", opacity: 0.85 }}>
          <div style={{ width: 390, height: 844, transform: "scale(2.205)", transformOrigin: "0 0" }}>
            <Home f={f} />
          </div>
        </div>
        <div style={{ position: "absolute", left: 0, right: 0, top: 44, display: "flex", justifyContent: "center", transform: `translateY(${open * 6}px)` }}>
          <DynamicBar open={open} width={780} />
        </div>
      </Hero>
    </Frame>
  );
};

export const Burst: React.FC = () => {
  const T = (b: number) => bf(b) - bf(24);
  return (
    <div style={{ position: "absolute", inset: 0 }}>
      <Sequence from={T(24)} durationInFrames={T(26) - T(24)}><Unduh /></Sequence>
      <Sequence from={T(26)} durationInFrames={T(28) - T(26)}><Offline /></Sequence>
      <Sequence from={T(28)} durationInFrames={T(30) - T(28)}><Lokal /></Sequence>
      <Sequence from={T(30)} durationInFrames={T(32) - T(30)}><Dynamic /></Sequence>
    </div>
  );
};
