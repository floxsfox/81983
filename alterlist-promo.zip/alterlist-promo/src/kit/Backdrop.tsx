import React from "react";
import { HEIGHT, WIDTH } from "../beats";
import { rng } from "../util";
import { useBeatFx } from "./fx";

const NOISE =
  "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='220' height='220'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='2' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 0.55 0'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>\")";

const PARTS = (() => {
  const r = rng(7);
  return Array.from({ length: 34 }, () => ({
    x: r() * WIDTH,
    y0: r() * HEIGHT,
    s: 3 + r() * 7,
    v: 0.5 + r() * 1.6,
    o: 0.25 + r() * 0.5,
    ph: r() * 6.28,
    hot: r() > 0.45,
  }));
})();

/** Latar aurora merah-hitam yang bernapas mengikuti beat + debu cahaya */
export const Backdrop: React.FC<{
  colors?: [string, string, string];
  dim?: number;
  particles?: boolean;
}> = ({
  colors = ["#FA0107", "#7a0a14", "#1c2a52"],
  dim = 0,
  particles = true,
}) => {
  const { g, p, e } = useBeatFx();
  const t = g / 30;
  const blob = (
    c: string,
    cx: number,
    cy: number,
    size: number,
    op: number,
  ): React.CSSProperties => ({
    position: "absolute",
    left: cx - size / 2,
    top: cy - size / 2,
    width: size,
    height: size,
    borderRadius: "50%",
    background: `radial-gradient(circle, ${c} 0%, transparent 64%)`,
    opacity: op,
  });
  const boost = 0.12 * p + 0.25 * e;
  return (
    <div style={{ position: "absolute", inset: 0, background: "#050506", overflow: "hidden" }}>
      <div style={blob(colors[0], 220 + Math.sin(t * 0.8) * 160, 380 + Math.cos(t * 0.6) * 140, 1500, 0.5 + boost)} />
      <div style={blob(colors[1], 880 + Math.cos(t * 0.7) * 150, 1180 + Math.sin(t * 0.9) * 170, 1700, 0.55 + boost * 0.8)} />
      <div style={blob(colors[2], 540 + Math.sin(t * 0.5 + 2) * 260, 1700 + Math.cos(t * 0.7) * 100, 1400, 0.5)} />
      {particles &&
        PARTS.map((q, i) => {
          const y = (((q.y0 - g * q.v * 2.2) % (HEIGHT + 80)) + HEIGHT + 80) % (HEIGHT + 80) - 40;
          const x = q.x + Math.sin(t * 0.9 + q.ph) * 24;
          const tw = 0.55 + 0.45 * Math.sin(t * 2.4 + q.ph) + p * 0.3;
          return (
            <div
              key={i}
              style={{
                position: "absolute",
                left: x,
                top: y,
                width: q.s,
                height: q.s,
                borderRadius: "50%",
                background: q.hot ? "#ff3b3f" : "#ffffff",
                opacity: Math.max(0, Math.min(1, q.o * tw)),
                boxShadow: q.hot ? "0 0 18px 4px rgba(250,1,7,0.55)" : "0 0 12px 2px rgba(255,255,255,0.35)",
              }}
            />
          );
        })}
      {/* vignette */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          background: "radial-gradient(120% 90% at 50% 45%, transparent 38%, rgba(0,0,0,0.78) 100%)",
        }}
      />
      {/* grain film */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          backgroundImage: NOISE,
          opacity: 0.07,
          mixBlendMode: "overlay",
        }}
      />
      {dim > 0 && <div style={{ position: "absolute", inset: 0, background: `rgba(0,0,0,${dim})` }} />}
    </div>
  );
};
