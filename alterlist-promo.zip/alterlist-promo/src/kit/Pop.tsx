import React from "react";
import { useCurrentFrame } from "remotion";
import { FONT } from "../theme";
import { eOut, eOutBack, eOutExpo, lerp, prog } from "../util";

/**
 * Animasi masuk teks/objek tepat di frame `at` (frame lokal Sequence):
 * naik + blur hilang + pop kecil. `out` = frame mulai keluar.
 */
export const Pop: React.FC<{
  at: number;
  out?: number;
  dur?: number;
  dist?: number;
  from?: "up" | "down" | "left" | "right" | "none";
  scaleFrom?: number;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({
  at,
  out,
  dur = 16,
  dist = 70,
  from = "up",
  scaleFrom = 0.82,
  style,
  children,
}) => {
  const f = useCurrentFrame();
  const t = prog(f, at, dur);
  const inOp = eOut(prog(f, at, 6));
  const k = eOutExpo(t);
  const x = from === "left" ? -dist : from === "right" ? dist : 0;
  const y = from === "up" ? dist : from === "down" ? -dist : 0;
  let op = inOp;
  let blur = (1 - eOut(prog(f, at, 11))) * 16;
  let ty = (1 - k) * y;
  let tx = (1 - k) * x;
  let sc = lerp(scaleFrom, 1, eOutBack(t, 1.4));
  if (out !== undefined) {
    const o = prog(f, out, 9);
    op *= 1 - o;
    blur += o * 14;
    ty -= o * 36;
    sc *= 1 + o * 0.06;
  }
  if (f < at) op = 0;
  return (
    <div
      style={{
        display: "inline-block",
        opacity: op,
        transform: `translate3d(${tx}px, ${ty}px, 0) scale(${sc})`,
        filter: blur > 0.3 ? `blur(${blur}px)` : undefined,
        willChange: "transform, opacity, filter",
        ...style,
      }}
    >
      {children}
    </div>
  );
};

/** gaya teks judul besar ala kinetic typography */
export const BIG: React.CSSProperties = {
  fontFamily: FONT,
  fontWeight: 700,
  color: "#fff",
  letterSpacing: "-0.035em",
  lineHeight: 0.98,
  textShadow: "0 10px 50px rgba(0,0,0,0.55)",
};
