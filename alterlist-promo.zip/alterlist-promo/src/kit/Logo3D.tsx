import React from "react";
import { Img, staticFile } from "remotion";

/** Logo Alterlist dengan ekstrusi 3D (tumpukan layer) + kilau kaca di muka depan */
export const Logo3D: React.FC<{
  size: number;
  rotY?: number;
  rotX?: number;
  rotZ?: number;
  depth?: number; // tebal ekstrusi dalam px
  shine?: number; // posisi kilau 0..1
  glow?: number; // 0..1
}> = ({ size, rotY = 0, rotX = 0, rotZ = 0, depth = 36, shine = -1, glow = 0.6 }) => {
  const layers = 14;
  const step = depth / layers;
  const mask = `url(${staticFile("logo.png")})`;
  return (
    <div style={{ width: size, height: size, perspective: 1600, position: "relative" }}>
      {/* aura */}
      <div
        style={{
          position: "absolute",
          left: -size * 0.4,
          top: -size * 0.4,
          width: size * 1.8,
          height: size * 1.8,
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(250,1,7,0.55) 0%, rgba(250,1,7,0.16) 38%, transparent 66%)",
          opacity: glow,
        }}
      />
      <div
        style={{
          position: "absolute",
          inset: 0,
          transformStyle: "preserve-3d",
          transform: `rotateX(${rotX}deg) rotateY(${rotY}deg) rotateZ(${rotZ}deg)`,
        }}
      >
        {Array.from({ length: layers }, (_, i) => {
          const d = layers - i; // layer paling belakang dulu
          return (
            <Img
              key={i}
              src={staticFile("logo.png")}
              style={{
                position: "absolute",
                inset: 0,
                width: "100%",
                height: "100%",
                transform: `translateZ(${-d * step}px)`,
                filter: `brightness(${0.32 + 0.4 * (1 - d / layers)}) saturate(1.2)`,
              }}
            />
          );
        })}
        {/* muka depan */}
        <div style={{ position: "absolute", inset: 0, transform: "translateZ(0.5px)" }}>
          <Img src={staticFile("logo.png")} style={{ width: "100%", height: "100%", filter: "brightness(1.08) saturate(1.1)" }} />
          <div
            style={{
              position: "absolute",
              inset: 0,
              WebkitMaskImage: mask,
              WebkitMaskSize: "100% 100%",
              WebkitMaskRepeat: "no-repeat",
              maskImage: mask,
              maskSize: "100% 100%",
              maskRepeat: "no-repeat",
              background:
                "linear-gradient(135deg, rgba(255,255,255,0.65) 0%, rgba(255,255,255,0) 34%, rgba(0,0,0,0) 60%, rgba(0,0,0,0.38) 100%)",
              mixBlendMode: "soft-light",
            }}
          />
          {shine >= 0 && shine <= 1 && (
            <div
              style={{
                position: "absolute",
                inset: 0,
                WebkitMaskImage: mask,
                WebkitMaskSize: "100% 100%",
                WebkitMaskRepeat: "no-repeat",
                maskImage: mask,
                maskSize: "100% 100%",
                maskRepeat: "no-repeat",
                background: "linear-gradient(105deg, transparent 40%, rgba(255,255,255,0.9) 50%, transparent 60%)",
                backgroundSize: "260% 100%",
                backgroundPosition: `${(1 - shine) * 100}% 0`,
                mixBlendMode: "overlay",
              }}
            />
          )}
        </div>
      </div>
    </div>
  );
};
