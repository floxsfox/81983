import React from "react";

export const SCREEN_W = 390;
export const SCREEN_H = 844;

/** Ponsel 3D (CSS): bodi, ketebalan, layar 390x844 di-scale, kilau kaca */
export const Phone: React.FC<{
  scale: number;
  rx?: number;
  ry?: number;
  rz?: number;
  x?: number;
  y?: number;
  z?: number;
  glare?: number;
  children: React.ReactNode;
}> = ({ scale: s, rx = 0, ry = 0, rz = 0, x = 0, y = 0, z = 0, glare = 0.5, children }) => {
  const bezel = 13;
  const w = SCREEN_W * s;
  const h = SCREEN_H * s;
  const W = w + bezel * 2;
  const H = h + bezel * 2;
  const Rs = 54 * s;
  const R = Rs + bezel;
  return (
    <div
      style={{
        position: "absolute",
        left: "50%",
        top: 0,
        width: W,
        height: H,
        marginLeft: -W / 2,
        transform: `perspective(2600px) translate3d(${x}px, ${y}px, ${z}px) rotateX(${rx}deg) rotateY(${ry}deg) rotateZ(${rz}deg)`,
        transformStyle: "preserve-3d",
      }}
    >
      {/* cahaya merah di belakang */}
      <div
        style={{
          position: "absolute",
          left: -W * 0.35,
          top: H * 0.1,
          width: W * 1.7,
          height: H * 0.8,
          background: "radial-gradient(closest-side, rgba(250,1,7,0.38), transparent)",
          transform: "translateZ(-60px)",
        }}
      />
      {/* ketebalan bodi */}
      {Array.from({ length: 9 }, (_, i) => (
        <div
          key={i}
          style={{
            position: "absolute",
            inset: 0,
            borderRadius: R,
            background: i % 2 ? "#202023" : "#0c0c0e",
            transform: `translateZ(${-(i + 1) * 1.8}px)`,
          }}
        />
      ))}
      {/* bodi depan */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          borderRadius: R,
          background: "linear-gradient(145deg, #4a4a50 0%, #0a0a0b 38%, #1a1a1d 62%, #4a4a50 100%)",
          boxShadow: "0 0 0 2px #050505, inset 0 0 0 2px rgba(255,255,255,0.2), inset 0 0 0 5px #050506",
        }}
      />
      {/* tombol samping */}
      <div style={{ position: "absolute", right: -4, top: H * 0.24, width: 5, height: H * 0.1, borderRadius: 3, background: "#2a2a2e" }} />
      <div style={{ position: "absolute", left: -4, top: H * 0.2, width: 5, height: H * 0.05, borderRadius: 3, background: "#2a2a2e" }} />
      <div style={{ position: "absolute", left: -4, top: H * 0.28, width: 5, height: H * 0.08, borderRadius: 3, background: "#2a2a2e" }} />
      {/* layar */}
      <div
        style={{
          position: "absolute",
          left: bezel,
          top: bezel,
          width: w,
          height: h,
          borderRadius: Rs,
          overflow: "hidden",
          background: "#000",
          transform: "translateZ(0.5px)",
        }}
      >
        <div style={{ width: SCREEN_W, height: SCREEN_H, transform: `scale(${s})`, transformOrigin: "0 0", position: "relative" }}>
          {children}
        </div>
        <div
          style={{
            position: "absolute",
            inset: 0,
            background: `linear-gradient(115deg, rgba(255,255,255,${0.2 * glare}) 0%, rgba(255,255,255,0.03) 32%, transparent 52%)`,
            mixBlendMode: "screen",
            pointerEvents: "none",
          }}
        />
      </div>
    </div>
  );
};
