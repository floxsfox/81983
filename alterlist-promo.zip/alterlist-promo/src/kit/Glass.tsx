import React from "react";

/**
 * Liquid glass: blur + saturasi, tepi bertebal (refraksi palsu), kilau spekular
 * dan bias warna. Satu backdrop-filter per panel supaya render tetap ringan.
 */
export const Glass: React.FC<{
  radius?: number;
  blur?: number;
  tint?: string; // warna bias, mis. "rgba(250,1,7,0.18)"
  sheen?: number; // posisi kilau 0..1 (di luar rentang = tersembunyi)
  strength?: number; // 0..1 kecerahan kaca
  shadow?: boolean;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({
  radius = 40,
  blur = 26,
  tint,
  sheen = -1,
  strength = 1,
  shadow = true,
  style,
  children,
}) => {
  const a = (v: number) => (v * strength).toFixed(3);
  return (
    <div
      style={{
        position: "relative",
        borderRadius: radius,
        overflow: "hidden",
        background: `linear-gradient(140deg, rgba(255,255,255,${a(0.2)}) 0%, rgba(255,255,255,${a(0.05)}) 38%, rgba(255,255,255,${a(0.09)}) 100%)`,
        backdropFilter: `blur(${blur}px) saturate(185%) brightness(1.12)`,
        WebkitBackdropFilter: `blur(${blur}px) saturate(185%) brightness(1.12)`,
        boxShadow: [
          `inset 0 1.5px 0 rgba(255,255,255,${a(0.6)})`,
          `inset 0 -1.5px 0 rgba(255,255,255,${a(0.1)})`,
          `inset 7px 7px 16px -8px rgba(255,255,255,${a(0.55)})`,
          `inset -7px -9px 18px -10px rgba(255,255,255,${a(0.28)})`,
          `inset 0 0 40px rgba(255,255,255,${a(0.05)})`,
          shadow ? "0 24px 60px rgba(0,0,0,0.5)" : "none",
        ].join(","),
        ...style,
      }}
    >
      {tint && (
        <div style={{ position: "absolute", inset: 0, background: tint }} />
      )}
      {/* kilau sudut atas-kiri */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          background: `radial-gradient(120% 90% at 0% 0%, rgba(255,255,255,${a(0.32)}), transparent 52%)`,
          pointerEvents: "none",
        }}
      />
      {/* cincin tepi bergradasi */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          borderRadius: radius,
          padding: 1.6,
          background:
            "linear-gradient(135deg, rgba(255,255,255,0.95), rgba(255,255,255,0.06) 34%, rgba(255,255,255,0) 62%, rgba(255,255,255,0.55))",
          WebkitMask:
            "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)",
          WebkitMaskComposite: "xor",
          maskComposite: "exclude",
          pointerEvents: "none",
          opacity: strength,
        }}
      />
      {/* sapuan kilau */}
      {sheen >= 0 && sheen <= 1 && (
        <div
          style={{
            position: "absolute",
            inset: "-20%",
            background:
              "linear-gradient(112deg, transparent 38%, rgba(255,255,255,0.34) 48%, rgba(255,255,255,0.06) 56%, transparent 66%)",
            transform: `translateX(${(sheen - 0.5) * 160}%)`,
            mixBlendMode: "screen",
            pointerEvents: "none",
          }}
        />
      )}
      <div style={{ position: "relative" }}>{children}</div>
    </div>
  );
};
