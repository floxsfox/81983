import React from "react";

type Name =
  | "play" | "pause" | "next" | "prev" | "shuffle" | "repeat1" | "heart"
  | "download" | "check" | "search" | "home" | "library" | "chart" | "history"
  | "user" | "lyrics" | "sliders" | "queue" | "wifioff" | "folder" | "phone"
  | "music" | "chevdown" | "more" | "sparkle" | "flame" | "headphones" | "bolt";

const S = (d: string) => <path d={d} />;

const PATHS: Record<Name, { fill?: boolean; node: React.ReactNode }> = {
  play: { fill: true, node: <polygon points="7 4 20 12 7 20" /> },
  pause: { fill: true, node: <><rect x="6" y="4.5" width="4.2" height="15" rx="1.2" /><rect x="13.8" y="4.5" width="4.2" height="15" rx="1.2" /></> },
  next: { fill: true, node: <><polygon points="5 4 15 12 5 20" /><rect x="17" y="4.5" width="2.6" height="15" rx="1.2" /></> },
  prev: { fill: true, node: <><polygon points="19 4 9 12 19 20" /><rect x="4.4" y="4.5" width="2.6" height="15" rx="1.2" /></> },
  shuffle: { node: S("M16 3h5v5M4 20 21 3M21 16v5h-5M15 15l6 6M4 4l5 5") },
  repeat1: { node: <>{S("M17 1l4 4-4 4M3 11V9a4 4 0 0 1 4-4h14M7 23l-4-4 4-4M21 13v2a4 4 0 0 1-4 4H3")}<path d="M11 10l1.5-1v6" /></> },
  heart: { node: S("M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z") },
  download: { node: S("M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3") },
  check: { node: S("M20 6 9 17l-5-5") },
  search: { node: <><circle cx="11" cy="11" r="7.5" />{S("M21 21l-4.6-4.6")}</> },
  home: { node: S("M3 10l9-7 9 7v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2zM9 22V13h6v9") },
  library: { node: S("M4 4v16M9 4v16M14.5 5.5l5 14.5") },
  chart: { node: S("M18 20V10M12 20V4M6 20v-6") },
  history: { node: <><circle cx="12" cy="12" r="9" />{S("M12 7v5l3 3")}</> },
  user: { node: <>{S("M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2")}<circle cx="12" cy="7" r="4" /></> },
  lyrics: { node: S("M4 6h16M4 12h10M4 18h13") },
  sliders: { node: S("M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6") },
  queue: { node: S("M3 6h12M3 12h12M3 18h7M18 14l4 3-4 3z") },
  wifioff: { node: S("M1 1l22 22M16.7 11.1A11 11 0 0 1 19 12.6M5 12.6a11 11 0 0 1 5.2-2.4M10.7 5.1A16 16 0 0 1 22.6 9M1.4 9a16 16 0 0 1 4.7-2.9M8.5 16.1a6 6 0 0 1 7 0M12 20h.01") },
  folder: { node: S("M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z") },
  phone: { node: <><rect x="5" y="2" width="14" height="20" rx="3" />{S("M12 18h.01")}</> },
  music: { node: <>{S("M9 18V5l12-2v13")}<circle cx="6" cy="18" r="3" /><circle cx="18" cy="16" r="3" /></> },
  chevdown: { node: S("M6 9l6 6 6-6") },
  more: { fill: true, node: <><circle cx="5" cy="12" r="1.8" /><circle cx="12" cy="12" r="1.8" /><circle cx="19" cy="12" r="1.8" /></> },
  sparkle: { fill: true, node: S("M12 2.5l2.1 5.9 5.9 2.1-5.9 2.1L12 18.5l-2.1-5.9L4 10.5l5.9-2.1z") },
  flame: { fill: true, node: S("M12 2c1.2 4.2 5.6 6.2 5.6 11.2a5.6 5.6 0 0 1-11.2 0c0-2.2 1-3.6 2.2-4.8.1 2.2 1 3.2 2.1 3.4-.9-3.4-.4-6.6 1.3-9.8z") },
  headphones: { node: S("M3 18v-6a9 9 0 0 1 18 0v6M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z") },
  bolt: { fill: true, node: S("M13 2 4 14h7l-1 8 9-12h-7z") },
};

export const Icon: React.FC<{
  name: Name;
  size?: number;
  color?: string;
  stroke?: number;
  style?: React.CSSProperties;
}> = ({ name, size = 24, color = "#fff", stroke = 2, style }) => {
  const p = PATHS[name];
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill={p.fill ? color : "none"}
      stroke={p.fill ? "none" : color}
      strokeWidth={stroke}
      strokeLinecap="round"
      strokeLinejoin="round"
      style={{ display: "block", flexShrink: 0, ...style }}
    >
      {p.node}
    </svg>
  );
};
