import React from "react";
import { Img, staticFile } from "remotion";
import { C, FONT } from "../theme";
import { useBeatFx } from "./fx";

/** Pill "dynamic bar" ala island: cover mini + gelombang + judul. open 0..1 */
export const DynamicBar: React.FC<{ open: number; width?: number }> = ({ open, width = 760 }) => {
  const { g, p } = useBeatFx();
  const w = 190 + (width - 190) * open;
  const h = 84 + 70 * open;
  return (
    <div
      style={{
        width: w,
        height: h,
        borderRadius: h / 2.2,
        background: "#000",
        boxShadow: "0 24px 70px rgba(0,0,0,0.65), 0 0 0 1.5px rgba(255,255,255,0.14), 0 0 60px rgba(250,1,7,0.22)",
        display: "flex",
        alignItems: "center",
        padding: `0 ${22 + 8 * open}px`,
        gap: 18,
        fontFamily: FONT,
        color: "#fff",
        overflow: "hidden",
        position: "relative",
      }}
    >
      <Img src={staticFile("cover.jpg")} style={{ width: h - 26, height: h - 26, borderRadius: (h - 26) / 3, objectFit: "cover" }} />
      <div style={{ flex: 1, opacity: open, lineHeight: 1.15, minWidth: 0 }}>
        <div style={{ fontSize: 44, fontWeight: 700, letterSpacing: "-0.02em" }}>crimes</div>
        <div style={{ fontSize: 30, color: C.sub, fontWeight: 500 }}>isq</div>
      </div>
      <div style={{ display: "flex", gap: 6, alignItems: "center", height: 56 }}>
        {[0, 1, 2, 3, 4].map((i) => {
          const hh = 14 + 34 * Math.abs(Math.sin(g * 0.22 + i * 1.3)) * (0.6 + 0.6 * p);
          return <i key={i} style={{ width: 7, height: hh, borderRadius: 4, background: C.red, boxShadow: "0 0 12px rgba(250,1,7,0.8)" }} />;
        })}
      </div>
    </div>
  );
};
