import React, { createContext, useContext, useEffect, useState } from "react";
import { continueRender, delayRender, staticFile } from "remotion";
import { ENERGY, BRIGHT } from "../envelope";
import { phrase, pulse } from "../beats";

/** frame global (0..689), tersedia di dalam semua <Sequence> */
export const GFrame = createContext(0);
export const useG = () => useContext(GFrame);

/** efek yang menempel ke beat lagu */
export const useBeatFx = () => {
  const g = useG();
  const i = Math.min(ENERGY.length - 1, Math.max(0, g));
  return {
    g,
    p: pulse(g, 5), // 1 di beat -> 0
    pSoft: pulse(g, 2.2),
    ph: phrase(g), // aksen frasa 8 beat
    e: ENERGY[i],
    b: BRIGHT[i],
  };
};

const FONTS: [number, string][] = [
  [400, "fonts/figtree_regular.ttf"],
  [500, "fonts/figtree_medium.ttf"],
  [600, "fonts/figtree_semibold.ttf"],
  [700, "fonts/figtree_bold.ttf"],
];

/** Tahan render sampai font Figtree (dari aplikasi) selesai dimuat */
export const FontGate: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [handle] = useState(() => delayRender("Memuat font Figtree"));
  useEffect(() => {
    Promise.all(
      FONTS.map(([w, file]) =>
        new FontFace("Figtree", `url(${staticFile(file)})`, {
          weight: String(w),
        })
          .load()
          .then((ff) => {
            document.fonts.add(ff);
          }),
      ),
    )
      .catch(() => undefined)
      .finally(() => continueRender(handle));
  }, [handle]);
  return <>{children}</>;
};
