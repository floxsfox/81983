import React from "react";
import { AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame } from "remotion";
import { DURATION, bf } from "./beats";
import { FontGate, GFrame } from "./kit/fx";
import { Burst } from "./scenes/Burst";
import { Carousel } from "./scenes/Carousel";
import { Hook } from "./scenes/Hook";
import { Outro } from "./scenes/Outro";
import { PhoneStage } from "./scenes/PhoneStage";
import { Reveal } from "./scenes/Reveal";
import { clamp } from "./util";

// potongan jatuh di beat; amp = kekuatan kilatan putih-merah
const FLASHES: { beat: number; amp: number }[] = [
  { beat: 8, amp: 0.95 },
  { beat: 12, amp: 0.55 },
  { beat: 16, amp: 0.7 },
  { beat: 20, amp: 0.5 },
  { beat: 24, amp: 0.9 },
  { beat: 26, amp: 0.45 },
  { beat: 28, amp: 0.45 },
  { beat: 30, amp: 0.45 },
  { beat: 32, amp: 0.9 },
  { beat: 40, amp: 0.95 },
];

const Flash: React.FC = () => {
  const f = useCurrentFrame();
  let a = 0;
  for (const s of FLASHES) {
    const d = f - bf(s.beat);
    if (d >= 0 && d < 14) a = Math.max(a, s.amp * Math.exp(-d / 3.2));
  }
  if (a < 0.01) return null;
  return (
    <AbsoluteFill
      style={{
        background: "radial-gradient(circle at 50% 50%, rgba(255,240,240,1), rgba(255,90,95,0.9) 60%, rgba(250,1,7,0.8))",
        opacity: a,
        mixBlendMode: "screen",
        pointerEvents: "none",
      }}
    />
  );
};

const S = (from: number, to: number, child: React.ReactNode) => (
  <Sequence from={bf(from)} durationInFrames={(to === 99 ? DURATION : bf(to)) - bf(from)}>
    {child}
  </Sequence>
);

export const Promo: React.FC = () => {
  const f = useCurrentFrame();
  const fadeIn = clamp(f / 10);
  const fadeOut = clamp((DURATION - f) / 16);
  return (
    <FontGate>
      <GFrame.Provider value={f}>
        <AbsoluteFill style={{ background: "#050506", opacity: Math.min(fadeIn, fadeOut) }}>
          <Audio src={staticFile("crimes.mp3")} />
          {S(0, 8, <Hook />)}
          {S(8, 12, <Reveal />)}
          {S(12, 24, <PhoneStage />)}
          {S(24, 32, <Burst />)}
          {S(32, 40, <Carousel />)}
          {S(40, 99, <Outro />)}
          <Flash />
        </AbsoluteFill>
      </GFrame.Provider>
    </FontGate>
  );
};
