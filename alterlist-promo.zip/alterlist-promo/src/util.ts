export const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
/** progres 0..1 dari frame `start` selama `dur` frame */
export const prog = (f: number, start: number, dur: number) =>
  clamp((f - start) / dur);

export const eOut = (t: number) => 1 - Math.pow(1 - t, 3);
export const eOutQuart = (t: number) => 1 - Math.pow(1 - t, 4);
export const eOutExpo = (t: number) => (t >= 1 ? 1 : 1 - Math.pow(2, -10 * t));
export const eInCubic = (t: number) => t * t * t;
export const eInOut = (t: number) =>
  t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
export const eOutBack = (t: number, s = 1.70158) => {
  const c3 = s + 1;
  return 1 + c3 * Math.pow(t - 1, 3) + s * Math.pow(t - 1, 2);
};

/** map nilai x dari [a,b] ke [c,d] (di-clamp) dengan easing opsional */
export const map = (
  x: number,
  a: number,
  b: number,
  c: number,
  d: number,
  ease: (t: number) => number = (t) => t,
) => lerp(c, d, ease(clamp((x - a) / (b - a))));

/** PRNG deterministik supaya render selalu sama */
export const rng = (seed: number) => {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
};
