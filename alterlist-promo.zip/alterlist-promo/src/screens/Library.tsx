import React from "react";
import { Glass } from "../kit/Glass";
import { Icon } from "../kit/Icon";
import { C } from "../theme";
import { Art, BottomNav, Screen, StatusBar } from "./common";

const Item: React.FC<{ icon: "heart" | "download" | "phone"; title: string; sub: string; c: string }> = ({ icon, title, sub, c }) => (
  <div style={{ display: "flex", alignItems: "center", gap: 14, height: 70 }}>
    <div style={{ width: 54, height: 54, borderRadius: 14, background: c, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 6px 16px rgba(0,0,0,0.4)" }}>
      <Icon name={icon} size={26} />
    </div>
    <div style={{ lineHeight: 1.2 }}>
      <div style={{ fontSize: 17, fontWeight: 600 }}>{title}</div>
      <div style={{ fontSize: 13.5, color: C.sub, fontWeight: 500 }}>{sub}</div>
    </div>
  </div>
);

export const Library: React.FC<{ f: number }> = () => (
  <Screen glow="#3a0c2a">
    <StatusBar />
    <div style={{ position: "absolute", left: 20, top: 62, fontSize: 28, fontWeight: 700, letterSpacing: "-0.4px" }}>Koleksi</div>
    <div style={{ position: "absolute", left: 16, top: 116, display: "flex", gap: 8 }}>
      {["Semua", "Playlist", "Artis"].map((t, i) => (
        <Glass key={t} radius={18} blur={12} strength={i === 0 ? 1.6 : 0.9} shadow={false}>
          <div style={{ padding: "7px 16px", fontSize: 14, fontWeight: 600 }}>{t}</div>
        </Glass>
      ))}
    </div>
    <div style={{ position: "absolute", left: 20, right: 20, top: 176 }}>
      <Item icon="heart" title="Lagu disukai" sub="128 lagu" c="linear-gradient(145deg,#ff4a50,#7a0a14)" />
      <Item icon="download" title="Diunduh" sub="Bisa diputar offline" c="linear-gradient(145deg,#2fd6a5,#0a4a4a)" />
      <Item icon="phone" title="Di perangkat" sub="Dari perangkatmu" c="linear-gradient(145deg,#4d7cff,#0b1d52)" />
    </div>
    <div style={{ position: "absolute", left: 20, top: 408, fontSize: 21, fontWeight: 700 }}>Playlist</div>
    <div style={{ position: "absolute", left: 20, right: 20, top: 452, display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
      {[0, 3, 4, 5, 6, 7].map((i) => (
        <div key={i}>
          <Art i={i} size={112} radius={14} />
          <div style={{ fontSize: 13, fontWeight: 600, marginTop: 6 }}>Playlist {i + 1}</div>
        </div>
      ))}
    </div>
    <BottomNav active={2} progress={0.38} />
  </Screen>
);
