import React from "react";
import { Img, staticFile } from "remotion";
import { Glass } from "../kit/Glass";
import { Icon } from "../kit/Icon";
import { useBeatFx } from "../kit/fx";
import { C, FONT } from "../theme";
import { clamp, eInOut, lerp } from "../util";
import { Screen, StatusBar } from "./common";

const LYRICS = [
  "Lirik ikut berjalan",
  "mengikuti setiap baris",
  "yang sedang dinyanyikan,",
  "kata demi kata",
  "menyala tepat waktu",
];

const fmt = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`;

/** lyr: 0 = mode cover, 1 = mode lirik. active: indeks baris lirik (boleh desimal) */
export const NowPlaying: React.FC<{ lyr?: number; active?: number }> = ({ lyr = 0, active = 0 }) => {
  const { g, p } = useBeatFx();
  const k = eInOut(clamp(lyr));
  const time = g / 30 + 41;
  const total = 101.5;
  const coverSize = lerp(318, 74, k);
  const coverX = lerp(36, 24, k);
  const coverY = lerp(150, 100, k);
  return (
    <Screen glow="#3a1014">
      {/* latar dari cover (blur) */}
      <Img src={staticFile("cover.jpg")} style={{ position: "absolute", inset: -40, width: 470, height: 924, objectFit: "cover", filter: "blur(46px) saturate(1.4) brightness(0.5)", opacity: 0.9 }} />
      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to bottom, rgba(12,12,13,0.25), rgba(12,12,13,0.78) 70%)" }} />
      <StatusBar />
      <div style={{ position: "absolute", left: 18, right: 18, top: 58, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <Icon name="chevdown" size={30} />
        <div style={{ fontSize: 13, fontWeight: 600, letterSpacing: "0.04em", opacity: 0.85 }}>SEDANG DIPUTAR</div>
        <Icon name="more" size={24} />
      </div>

      {/* cover (mengecil saat mode lirik) */}
      <Img
        src={staticFile("cover.jpg")}
        style={{
          position: "absolute",
          left: coverX,
          top: coverY,
          width: coverSize,
          height: coverSize,
          borderRadius: lerp(22, 14, k),
          objectFit: "cover",
          boxShadow: "0 30px 60px rgba(0,0,0,0.55)",
          transform: `scale(${1 + 0.018 * p * (1 - k)})`,
        }}
      />
      {/* judul */}
      <div style={{ position: "absolute", left: lerp(36, 112, k), top: lerp(486, 112, k), right: 30, lineHeight: 1.15 }}>
        <div style={{ fontSize: lerp(27, 21, k), fontWeight: 700, letterSpacing: "-0.4px" }}>crimes</div>
        <div style={{ fontSize: lerp(17, 15, k), fontWeight: 500, color: C.sub }}>isq</div>
      </div>
      <div style={{ position: "absolute", right: 34, top: 494, opacity: 1 - k }}>
        <Icon name="heart" size={28} color={C.red} />
      </div>

      {/* lirik */}
      <div style={{ position: "absolute", left: 26, right: 26, top: 214, opacity: k }}>
        {LYRICS.map((l, i) => {
          const d = Math.abs(i - active);
          const on = clamp(1 - d);
          return (
            <div
              key={l}
              style={{
                fontFamily: FONT,
                fontSize: 27,
                fontWeight: 700,
                letterSpacing: "-0.5px",
                lineHeight: 1.2,
                margin: "0 0 18px",
                color: `rgba(255,255,255,${lerp(0.32, 1, on)})`,
                transform: `translateX(${lerp(0, 8, on)}px) scale(${lerp(0.97, 1.02, on)})`,
                transformOrigin: "0 50%",
                filter: d > 1.6 ? "blur(1.2px)" : undefined,
                textShadow: on > 0.5 ? "0 0 30px rgba(255,255,255,0.35)" : "none",
              }}
            >
              {l}
            </div>
          );
        })}
        <div style={{ fontSize: 16, fontWeight: 500, color: C.red, marginTop: 6 }}>Terjemahan muncul di bawahnya</div>
      </div>

      {/* progres + kontrol dalam kaca */}
      <div style={{ position: "absolute", left: 16, right: 16, bottom: 36 }}>
        <Glass radius={34} blur={24} tint="rgba(20,4,6,0.35)">
          <div style={{ padding: "22px 22px 18px" }}>
            <div style={{ height: 5, borderRadius: 3, background: "rgba(255,255,255,0.22)", position: "relative" }}>
              <div style={{ width: `${(time / total) * 100}%`, height: "100%", borderRadius: 3, background: "#fff" }} />
              <div style={{ position: "absolute", left: `${(time / total) * 100}%`, top: -4, width: 13, height: 13, borderRadius: "50%", background: "#fff", marginLeft: -6 }} />
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: C.sub, fontWeight: 500, margin: "9px 0 6px" }}>
              <span>{fmt(time)}</span>
              <span>{fmt(total)}</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "0 6px" }}>
              <Icon name="shuffle" size={24} color={C.sub} />
              <Icon name="prev" size={32} />
              <div style={{ width: 70, height: 70, borderRadius: "50%", background: "#fff", display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${1 + 0.05 * p})`, boxShadow: "0 8px 30px rgba(255,255,255,0.25)" }}>
                <Icon name="pause" size={34} color="#0C0C0D" />
              </div>
              <Icon name="next" size={32} />
              <Icon name="repeat1" size={24} color={C.red} />
            </div>
            <div style={{ display: "flex", justifyContent: "space-around", marginTop: 20 }}>
              <Icon name="lyrics" size={24} color={k > 0.5 ? C.red : "#fff"} />
              <Icon name="sliders" size={24} />
              <Icon name="queue" size={24} />
              <Icon name="download" size={24} />
            </div>
          </div>
        </Glass>
      </div>
    </Screen>
  );
};
