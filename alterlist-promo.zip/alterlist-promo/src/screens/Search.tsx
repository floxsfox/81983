import React from "react";
import { Glass } from "../kit/Glass";
import { Icon } from "../kit/Icon";
import { C } from "../theme";
import { Art, BottomNav, Screen, StatusBar } from "./common";

const GENRES = ["Pop", "Indie", "Lo-fi", "Rock", "Jazz", "Hip-hop", "R&B", "Akustik"];

export const Search: React.FC<{ f: number }> = ({ f }) => (
  <Screen glow="#14285a">
    <StatusBar />
    <div style={{ position: "absolute", left: 20, top: 62, fontSize: 28, fontWeight: 700, letterSpacing: "-0.4px" }}>Cari</div>
    <div style={{ position: "absolute", left: 16, right: 16, top: 116 }}>
      <Glass radius={26} blur={18} style={{ height: 52 }}>
        <div style={{ height: 52, display: "flex", alignItems: "center", gap: 10, padding: "0 18px", fontSize: 16, fontWeight: 500, color: "rgba(255,255,255,0.7)" }}>
          <Icon name="search" size={21} color="#fff" />
          <span>Lagu, artis, album{f % 30 < 15 ? "|" : ""}</span>
        </div>
      </Glass>
    </div>
    <div style={{ position: "absolute", left: 20, top: 190, fontSize: 21, fontWeight: 700 }}>Genre favorit</div>
    <div style={{ position: "absolute", left: 16, right: 16, top: 232, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
      {GENRES.map((g, i) => (
        <div key={g} style={{ height: 92, borderRadius: 16, overflow: "hidden", position: "relative" }}>
          <Art i={i + 1} size={200} radius={0} style={{ width: "100%", height: 92, boxShadow: "none" }} />
          <div style={{ position: "absolute", left: 14, top: 12, fontSize: 19, fontWeight: 700, letterSpacing: "-0.3px" }}>{g}</div>
        </div>
      ))}
    </div>
    <div style={{ position: "absolute", left: 20, right: 20, top: 612, fontSize: 13, color: C.sub, fontWeight: 500 }} />
    <BottomNav active={1} progress={0.36} />
  </Screen>
);
