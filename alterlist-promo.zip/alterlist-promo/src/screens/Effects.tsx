import React from "react";
import { Glass } from "../kit/Glass";
import { Icon } from "../kit/Icon";
import { useBeatFx } from "../kit/fx";
import { C } from "../theme";
import { clamp, eOutQuart } from "../util";
import { Screen, StatusBar } from "./common";

const PRESETS = ["Normal", "Slowed", "Nightcore", "8D", "3D", "Reverb"];

const Slider: React.FC<{ label: string; value: number; shown: string }> = ({ label, value, shown }) => (
  <div style={{ margin: "0 0 22px" }}>
    <div style={{ display: "flex", justifyContent: "space-between", fontSize: 15, fontWeight: 600, marginBottom: 10 }}>
      <span>{label}</span>
      <span style={{ color: C.redSoft }}>{shown}</span>
    </div>
    <div style={{ height: 8, borderRadius: 4, background: "rgba(255,255,255,0.16)", position: "relative" }}>
      <div style={{ width: `${value * 100}%`, height: "100%", borderRadius: 4, background: "linear-gradient(90deg,#ff4a50,#FA0107)", boxShadow: "0 0 16px rgba(250,1,7,0.7)" }} />
      <div style={{ position: "absolute", left: `${value * 100}%`, top: -7, width: 22, height: 22, borderRadius: "50%", background: "#fff", marginLeft: -11, boxShadow: "0 3px 10px rgba(0,0,0,0.5)" }} />
    </div>
  </div>
);

/** sel = indeks preset terpilih, k = 0..1 progres geser slider */
export const Effects: React.FC<{ sel?: number; k?: number }> = ({ sel = 1, k = 1 }) => {
  const { g, p } = useBeatFx();
  const kk = eOutQuart(clamp(k));
  return (
    <Screen glow="#4a0c12">
      <StatusBar />
      <div style={{ position: "absolute", left: 20, right: 20, top: 66, fontSize: 28, fontWeight: 700, letterSpacing: "-0.4px", lineHeight: 1.05 }}>
        Efek suara,
        <br />
        3D dan 8D
      </div>
      <div style={{ position: "absolute", left: 16, right: 16, top: 168, display: "flex", flexWrap: "wrap", gap: 9 }}>
        {PRESETS.map((t, i) => {
          const on = i === sel;
          return (
            <Glass key={t} radius={20} blur={12} strength={on ? 1.9 : 0.8} tint={on ? "rgba(250,1,7,0.55)" : undefined} shadow={false}>
              <div style={{ padding: "9px 18px", fontSize: 15, fontWeight: 700 }}>{t}</div>
            </Glass>
          );
        })}
      </div>
      <div style={{ position: "absolute", left: 16, right: 16, top: 262 }}>
        <Glass radius={30} blur={22} tint="rgba(30,6,8,0.4)">
          <div style={{ padding: "26px 24px 8px" }}>
            <Slider label="Kecepatan putar" value={0.32 + 0.1 * kk} shown={`${(0.75 + 0.1 * kk).toFixed(2)}x`} />
            <Slider label="Reverb" value={0.2 + 0.58 * kk} shown={`${Math.round(20 + 58 * kk)}%`} />
            <Slider label="Kekuatan efek" value={0.3 + 0.5 * kk} shown={`${Math.round(30 + 50 * kk)}%`} />
          </div>
        </Glass>
      </div>
      <div style={{ position: "absolute", left: 20, top: 560, fontSize: 21, fontWeight: 700 }}>Equalizer</div>
      <div style={{ position: "absolute", left: 20, right: 20, top: 604, height: 150, display: "flex", alignItems: "flex-end", gap: 10 }}>
        {Array.from({ length: 10 }, (_, i) => {
          const base = 0.35 + 0.35 * Math.sin(i * 0.9 + g * 0.12);
          const h = clamp(base + 0.25 * p * (i % 3 === 0 ? 1 : 0.4), 0.12, 1);
          return (
            <div key={i} style={{ flex: 1, height: `${h * 100}%`, borderRadius: 8, background: "linear-gradient(to top,#FA0107,#ff8a8d)", boxShadow: "0 0 18px rgba(250,1,7,0.5)" }} />
          );
        })}
      </div>
      <div style={{ position: "absolute", left: 20, right: 20, bottom: 40, display: "flex", alignItems: "center", gap: 10, color: C.sub, fontSize: 13.5, fontWeight: 500 }}>
        <Icon name="sparkle" size={18} color={C.redSoft} />
        Hanya tempo yang berubah, nada tetap
      </div>
    </Screen>
  );
};
