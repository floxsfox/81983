import React from "react";
import { Img, staticFile } from "remotion";
import { Glass } from "../kit/Glass";
import { Icon } from "../kit/Icon";
import { C, FONT } from "../theme";

export const PAL: [string, string][] = [
  ["#ff5a5f", "#7a0a14"],
  ["#4d7cff", "#0b1d52"],
  ["#ffb347", "#a8321a"],
  ["#a56bff", "#2a0f5c"],
  ["#2fd6a5", "#0a4a4a"],
  ["#ff6ec7", "#5a0f4a"],
  ["#f5e663", "#8a4b08"],
  ["#5ad1ff", "#10315e"],
];

/** cover buatan (abstrak) supaya tidak memakai artwork pihak lain */
export const Art: React.FC<{ i: number; size: number; radius?: number; round?: boolean; label?: string; style?: React.CSSProperties }> = ({
  i, size, radius = 12, round, label, style,
}) => {
  const [a, b] = PAL[i % PAL.length];
  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: round ? "50%" : radius,
        background: `linear-gradient(145deg, ${a}, ${b})`,
        position: "relative",
        overflow: "hidden",
        flexShrink: 0,
        boxShadow: "0 6px 18px rgba(0,0,0,0.4)",
        ...style,
      }}
    >
      <div style={{ position: "absolute", width: size * 0.9, height: size * 0.9, borderRadius: "50%", left: -size * 0.25, top: -size * 0.3, background: "rgba(255,255,255,0.22)" }} />
      <div style={{ position: "absolute", width: size * 0.7, height: size * 0.7, borderRadius: "50%", right: -size * 0.2, bottom: -size * 0.25, background: "rgba(0,0,0,0.28)" }} />
      {label && (
        <div style={{ position: "absolute", left: size * 0.08, bottom: size * 0.07, fontFamily: FONT, fontWeight: 700, fontSize: size * 0.17, color: "#fff", letterSpacing: "-0.02em" }}>
          {label}
        </div>
      )}
    </div>
  );
};

export const CoverImg: React.FC<{ size: number; radius?: number; style?: React.CSSProperties }> = ({ size, radius = 10, style }) => (
  <Img src={staticFile("cover.jpg")} style={{ width: size, height: size, borderRadius: radius, objectFit: "cover", flexShrink: 0, ...style }} />
);

export const Screen: React.FC<{ glow?: string; children: React.ReactNode }> = ({ glow = "#4a1013", children }) => (
  <div style={{ position: "relative", width: 390, height: 844, background: C.bg, overflow: "hidden", fontFamily: FONT, color: "#fff" }}>
    <div style={{ position: "absolute", left: -60, top: -120, width: 520, height: 520, background: `radial-gradient(closest-side, ${glow}, transparent)`, opacity: 0.9 }} />
    {children}
  </div>
);

export const StatusBar: React.FC = () => (
  <div style={{ position: "absolute", left: 0, right: 0, top: 0, height: 50, padding: "16px 30px 0", display: "flex", justifyContent: "space-between", fontSize: 15, fontWeight: 600, zIndex: 5 }}>
    <span>12:30</span>
    <span style={{ display: "flex", gap: 6, alignItems: "center", opacity: 0.95 }}>
      <span style={{ display: "flex", gap: 2, alignItems: "flex-end" }}>
        {[5, 8, 11, 14].map((h) => <i key={h} style={{ width: 3, height: h, background: "#fff", borderRadius: 1 }} />)}
      </span>
      <span style={{ width: 24, height: 12, border: "1.5px solid rgba(255,255,255,0.7)", borderRadius: 4, padding: 1.5 }}>
        <span style={{ display: "block", width: "72%", height: "100%", background: "#fff", borderRadius: 2 }} />
      </span>
    </span>
  </div>
);

/** nav bawah: fade-out gelap + kaca, sama seperti di aplikasi */
export const BottomNav: React.FC<{ active: 0 | 1 | 2; mini?: boolean; playing?: boolean; progress?: number }> = ({ active, mini = true, playing = true, progress = 0.3 }) => {
  const tabs: [string, "home" | "search" | "library"][] = [["Beranda", "home"], ["Cari", "search"], ["Koleksi", "library"]];
  return (
    <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: 210, zIndex: 4 }}>
      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, #0C0C0D 18%, rgba(12,12,13,0.86) 55%, transparent)" }} />
      {mini && (
        <div style={{ position: "absolute", left: 14, right: 14, bottom: 96 }}>
          <Glass radius={22} blur={20} tint="rgba(80,10,14,0.32)" style={{ height: 62 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "9px 14px 9px 9px", height: 62, boxSizing: "border-box" }}>
              <Img src={staticFile("cover.jpg")} style={{ width: 44, height: 44, borderRadius: 10, objectFit: "cover" }} />
              <div style={{ flex: 1, lineHeight: 1.15 }}>
                <div style={{ fontSize: 15, fontWeight: 600 }}>crimes</div>
                <div style={{ fontSize: 12.5, color: C.sub, fontWeight: 500 }}>isq</div>
              </div>
              <Icon name="heart" size={22} color="#fff" />
              <Icon name={playing ? "pause" : "play"} size={26} />
            </div>
            <div style={{ position: "absolute", left: 14, right: 14, bottom: 5, height: 2.5, borderRadius: 2, background: "rgba(255,255,255,0.22)" }}>
              <div style={{ width: `${progress * 100}%`, height: "100%", borderRadius: 2, background: "#fff" }} />
            </div>
          </Glass>
        </div>
      )}
      <div style={{ position: "absolute", left: 0, right: 0, bottom: 26, display: "flex", justifyContent: "space-around", padding: "0 20px" }}>
        {tabs.map(([label, ic], i) => (
          <div key={label} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4, opacity: i === active ? 1 : 0.5 }}>
            <Icon name={ic} size={26} color={i === active ? C.red : "#fff"} />
            <span style={{ fontSize: 11.5, fontWeight: 600, color: i === active ? "#fff" : C.sub }}>{label}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export const Row: React.FC<{ art: number; title: string; sub: string; right?: React.ReactNode; img?: boolean }> = ({ art, title, sub, right, img }) => (
  <div style={{ display: "flex", alignItems: "center", gap: 13, height: 60 }}>
    {img ? <CoverImg size={52} radius={9} /> : <Art i={art} size={52} radius={9} />}
    <div style={{ flex: 1, lineHeight: 1.2 }}>
      <div style={{ fontSize: 16, fontWeight: 600 }}>{title}</div>
      <div style={{ fontSize: 13, color: C.sub, fontWeight: 500 }}>{sub}</div>
    </div>
    {right}
  </div>
);
