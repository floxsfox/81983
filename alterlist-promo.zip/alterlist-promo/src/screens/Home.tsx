import React from "react";
import { Glass } from "../kit/Glass";
import { Icon } from "../kit/Icon";
import { C } from "../theme";
import { Art, BottomNav, Row, Screen, StatusBar } from "./common";

export const Home: React.FC<{ f: number }> = ({ f }) => {
  const scroll = f * 0.9;
  return (
    <Screen glow="#5a0f14">
      <StatusBar />
      <div style={{ position: "absolute", left: 20, right: 20, top: 62, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ fontSize: 28, fontWeight: 700, letterSpacing: "-0.4px" }}>Selamat siang</div>
        <div style={{ display: "flex", gap: 10 }}>
          {(["chart", "history", "user"] as const).map((n) => (
            <Glass key={n} radius={20} blur={14} style={{ width: 40, height: 40 }} shadow={false}>
              <div style={{ height: 40, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <Icon name={n} size={20} />
              </div>
            </Glass>
          ))}
        </div>
      </div>
      <div style={{ position: "absolute", left: 20, top: 132, fontSize: 21, fontWeight: 700, letterSpacing: "-0.2px" }}>Mix untukmu</div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 172, height: 190, overflow: "hidden" }}>
        <div style={{ display: "flex", gap: 14, paddingLeft: 20, transform: `translateX(${-scroll}px)` }}>
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <div key={i} style={{ width: 150, flexShrink: 0 }}>
              <Art i={i} size={150} radius={16} label={`MIX ${i + 1}`} />
              <div style={{ fontSize: 13, color: C.sub, marginTop: 8, fontWeight: 500 }}>Dari kebiasaanmu</div>
            </div>
          ))}
        </div>
      </div>
      <div style={{ position: "absolute", left: 20, right: 20, top: 392, fontSize: 21, fontWeight: 700, letterSpacing: "-0.2px" }}>Paling sering kamu putar</div>
      <div style={{ position: "absolute", left: 20, right: 20, top: 436 }}>
        <Row art={0} title="crimes" sub="isq" img right={<Icon name="more" size={20} color={C.sub} />} />
        <Row art={3} title="Slow Bloom" sub="Lumen" right={<Icon name="more" size={20} color={C.sub} />} />
        <Row art={4} title="Neon Rain" sub="Hazel Avenue" right={<Icon name="more" size={20} color={C.sub} />} />
        <Row art={2} title="Midnight Drive" sub="Oro" right={<Icon name="more" size={20} color={C.sub} />} />
      </div>
      <BottomNav active={0} progress={0.34} />
    </Screen>
  );
};
