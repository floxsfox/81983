// Warna & font diambil langsung dari Theme.kt aplikasi Alterlist
export const C = {
  red: "#FA0107",
  redSoft: "#FF4A50",
  bg: "#0C0C0D",
  surface: "#171718",
  surface2: "#242426",
  surface3: "#303033",
  sub: "#B3B3B3",
  muted: "#7C7C80",
  divider: "#2A2A2D",
  white: "#FFFFFF",
};

export const FONT =
  "'Figtree', system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif";
