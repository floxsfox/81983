// Semua teks di video ada di sini - ganti seperlunya.
export const COPY = {
  brand: "Alterlist",
  tagline: "Musik tanpa batas.",
  hook: {
    l1: "Musikmu tersebar.",
    chips: ["Akun YouTube Music", "Musik di HP", "Unduhan offline"],
    l2a: "Gimana kalau",
    l2b: "jadi satu?",
  },
  phone: {
    a1: "Semua musikmu.",
    a2: "Satu tempat.",
    b1: "Lirik sinkron.",
    b2: "Plus terjemahan.",
    fx: ["Slowed.", "Reverb.", "8D."],
  },
  burst: [
    { word: "Unduh.", desc: "Simpan lagu favoritmu." },
    { word: "Offline.", desc: "Tanpa sinyal tetap jalan." },
    { word: "Lagu lokal.", desc: "Musik di perangkatmu ikut masuk." },
    { word: "Dynamic bar.", desc: "Kontrol cepat di atas layar." },
  ],
  carousel: { l1: "Satu aplikasi.", l2: "Semua fiturnya.", l3: "Dengerin tiap hari.", l4: "Jaga apimu." },
  outro: { sub: "Android 10+", credit: "Credit by eliojioDev" },
};
