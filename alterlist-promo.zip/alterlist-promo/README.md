# Alterlist Promo (Remotion)

Video promosi aplikasi Alterlist — 1080x1920 (ponsel), 30 fps, 23 detik, lagu **isq - crimes** (0:00–0:23), tanpa sound effect.
Credit by eliojioDev.

## Render lewat GitHub Web
1. Upload `alterlist-promo.zip` ke root repo.
2. Buat `.github/workflows/render-promo.yml` (isi sama dengan file `render-promo.yml`).
3. Actions → **Render Video Promo Alterlist** → Run workflow. MP4 muncul di **Releases**.

## Render lokal
```
npm install
npm start          # preview di Remotion Studio
npm run render     # hasil: out/alterlist-promo.mp4
```

## Mau ubah apa
- Teks: `src/copy.ts`
- Waktu potongan/beat: `src/beats.ts` (122,2 BPM, 1 beat = 0,491 dtk, semua potongan jatuh tepat di beat)
- Adegan: `src/scenes/*` — Hook, Reveal, PhoneStage, Burst, Carousel, Outro
- Layar aplikasi tiruan: `src/screens/*`; liquid glass: `src/kit/Glass.tsx`
- Lagu sudah dipotong 0:00–0:23 (`public/crimes.mp3`); font Figtree (OFL) dari aplikasi.
